using System;
using System.Data;
using System.Data.Common; 
using Fwk.Bases;

using $BackendNamespace$.DAC;
using $BackendNamespace$.BC;

namespace $BackendNamespace$.BusinessComponent
{
    public class BusinessComponentsSample : BusinessComponent
    {
        //----------------------------
        // Implement your code here..
        //----------------------------
    }
}
