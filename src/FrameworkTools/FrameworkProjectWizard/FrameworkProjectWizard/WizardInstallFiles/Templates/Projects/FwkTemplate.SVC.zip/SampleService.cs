﻿//----------------------------
// 
//----------------------------

using System;
using System.Data;
using System.Collections.Generic;
using Fwk.Bases;
using $projectname$.Common.BE;
using $projectname$.BackEnd.BC;
using $projectname$.Common.ISVC.Sample;




namespace $projectname$.SVC
{
    public class SampleService : BusinessService<SampleReq, SampleRes>
    {
        public override SampleRes Execute(SampleReq req)
        {
            SampleRes res = new SampleRes();


            //----------------------------
            // Implement your code here..
            //----------------------------


            return res;
        }
    }
}
