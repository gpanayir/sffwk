﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.Common;
using Fwk.Exceptions;
using System.Data;

using $fwkprojectname$.Common.BE;

namespace $fwkprojectname$.BackEnd.DAC
{
    public class SampleDAC
    {
        // public static void Insert(SampleBE pSampleBE)
        //{
        //    Database wDataBase = null;
        //    DbCommand wCmd = null;

        //    try
        //    {
        //        wDataBase = DatabaseFactory.CreateDatabase(BigBang.Common.Constants.BigBangConnectionStringKey);
        //        wCmd = wDataBase.GetStoredProcCommand("SampleBETable_i");

             
        //        wDataBase.AddOutParameter(wCmd, "Id", System.Data.DbType.Int32, 4);
              
        //        wDataBase.AddInParameter(wCmd, "Param1", System.Data.DbType.Int32, pQuestion.Param2);
     
        //        wDataBase.AddInParameter(wCmd, "Param2", System.Data.DbType.Int32, pQuestion.Param2);
              

        //        /// EnableComments
        //        wDataBase.AddInParameter(wCmd, "EnableComments", System.Data.DbType.Boolean, pQuestion.EnableComments);

          

        //        wDataBase.ExecuteNonQuery(wCmd);
        //        pQuestion.QuestionId = (System.Int32)wDataBase.GetParameterValue(wCmd, "Id");
        //    }
        //    catch (Exception ex)
        //    {
        //        throw Fwk.Exceptions.ExceptionHelper.ProcessException(ex);
        //    }
        //}
    }
}
