﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fwk.Exceptions;

using $fwkprojectname$.BackEnd.DAC;
using $fwkprojectname$.Common.BE;

namespace $fwkprojectname$.BackEnd.BC
{
    public class SampleBC
    {
       
    }
}
