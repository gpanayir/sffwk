﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fwk.Exceptions;
using Fwk.Bases;
using $fwkprojectname$.BackEnd.DAC;
using $fwkprojectname$.Common.BE;

namespace $fwkprojectname$.BackEnd.BC
{
    public class SampleBC :BaseBC
    {
		public SampleBC(string pCompanyId):base(pCompanyId)
		{}
       
    }
}
