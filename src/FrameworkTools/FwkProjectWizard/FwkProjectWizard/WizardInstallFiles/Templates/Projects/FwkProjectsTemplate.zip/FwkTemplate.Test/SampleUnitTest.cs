﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fwk.HelperFunctions;
using Fwk.Bases.FrontEnd;
using Fwk.Transaction;
using Fwk.Bases;
using $fwkprojectname$.Common.ISVC.SearchClientByParam;

namespace $fwkprojectname$.Test
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class SampleUnitTest
    {
        public SampleUnitTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        TransactionScopeHandler _Tx;
        string _StrExceptionMessage = String.Empty;
        String xmlPath = @"\\Corrsf71bi01\BigBang\test";

        private TestContext testContextInstance;
        ClientServiceBase _ClientServiceBase = null;
    

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        #region test samples
        [TestMethod()]
        public void DeleteClientService_NoService()
        {
            String strErrorResut = String.Empty;
            _Tx = new TransactionScopeHandler(TransactionalBehaviour.RequiresNew, IsolationLevel.ReadCommitted, new TimeSpan(0, 0, 15));
            //DeleteClientRequest req = new DeleteClientRequest();
            //DeleteClientService svc = new DeleteClientService();


            //string s = Environment.CurrentDirectory;


            try
            {
                _Tx.InitScope();

                //req.BusinessData.UserId = 3;
                //req.BusinessData.ClientId = 1;
                //DeleteClientResponse res = svc.Execute(req);
                _Tx.Abort();
            }
            catch (Exception ex)
            {
                //strErrorResut = Common.Exceptions.ProcessException(res.Error).Message;
                //strErrorResut = res.Error.Message;
            }
            Assert.AreEqual<String>(strErrorResut, String.Empty, strErrorResut);
        }

         [TestMethod()]
        public void SearchClientByParamResService()
        {
            String strErrorResut = String.Empty;

            SearchClientByParamReq req = new SearchClientByParamReq();
            //req.BusinessData.ClientId = 35;
            SearchClientByParamRes res = _ClientServiceBase.ExecuteService<SearchClientByParamReq, SearchClientByParamRes>(req);

            if (res.Error != null)
            {
                //strErrorResut = Common.Exceptions.ProcessException(res.Error).Message;
                strErrorResut = res.Error.Message;
            }

            Assert.AreEqual<Fwk.Exceptions.ServiceError>(res.Error, null, strErrorResut);
        }
        #endregion
    }
}
