﻿//----------------------------
// 
//----------------------------

using System;
using System.Data;
using System.Collections.Generic;
using Fwk.Bases;
using $fwkprojectname$.Common.BE;
using $fwkprojectname$.BackEnd.BC;
using $fwkprojectname$.Common.ISVC.SearchClientByParam;




namespace $fwkprojectname$.BackEnd.SVC
{
    public class SearchClientByParamService : BusinessService<SearchClientByParamReq, SearchClientByParamRes>
    {
        public override SearchClientByParamRes Execute(SearchClientByParamReq req)
        {
            SearchClientByParamRes res = new SearchClientByParamRes();


            //----------------------------
            // Implement your code here..
            //----------------------------


            return res;
        }
    }
}
