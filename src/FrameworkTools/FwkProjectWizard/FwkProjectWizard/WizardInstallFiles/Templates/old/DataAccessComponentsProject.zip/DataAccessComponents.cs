using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Fwk.Bases;
using Fwk.Exceptions;
using $BackendNamespace$.BE;

namespace $BackendNamespace$.DataAccessComponent
{
    public class DataAccessComponentsSample 
    {
        //----------------------------
        // Implement your code here..
        //----------------------------
    }
}
