﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fwk.Bases;
using BigBang.Common.RecordSet.BE;
using System.Xml.Serialization;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using Fwk.Bases;

namespace $fwkprojectname$.Common.ISVC.$servicename$
{
    
    #region [Request]
    [Serializable]
    public class $servicename$Req : Request<Params>
    {
        public $servicename$Req()
        {
            base.ServiceName = "$servicename$Service";
        }
    }

     #region [BussinesData]
    [XmlInclude(typeof(Params)), Serializable]
    public class Params : Entity
    {

    }
    
    #endregion
    #endregion

    #region [Response]
    [Serializable]
    public class $servicename$Res: Response<Result>
    {
    }

    #region [BussinesData]

    [XmlInclude(typeof(Result)), Serializable]
    public class Result : Entity
    {
     

    }

    #endregion
    #endregion
}
