﻿
//----------------------------
// 
//----------------------------

using System;
using System.Data;
using System.Collections.Generic;
using Fwk.Bases;
using $fwkprojectname$.Common.BE;
using $fwkprojectname$.BackEnd.BC;
using $fwkprojectname$.Common.ISVC.$servicename$;




namespace $fwkprojectname$.BackEnd.SVC
{
    public class $servicename$Service : BusinessService<$servicename$Req, $servicename$Res>
    {
        public override $servicename$Res Execute($servicename$Req req)
        {
            $servicename$Res res = new $servicename$Res();


            //----------------------------
            // Implement your code here..
            //----------------------------


            return res;
        }
    }
}
