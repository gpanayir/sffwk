﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using Fwk.Bases;

namespace $fwkprojectname$.Common.BE
{
   
$fwkgencode$

}
