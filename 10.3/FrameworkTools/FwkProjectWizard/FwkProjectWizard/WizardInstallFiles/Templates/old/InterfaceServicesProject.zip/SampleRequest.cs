using System;
using System.Collections.Generic;
using System.Text;
using Fwk.Bases;
namespace $CommonNamespace$.ISVC
{
    
    public class SampleRequest : Request<SampleREQ>
    {
	base.ServiceName = "SampleService";
    }
}
